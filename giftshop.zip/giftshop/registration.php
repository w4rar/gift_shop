<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <!--
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    Tanggalin mo nalang yung bootstrap kung di kailangan-->
    <link rel="stylesheet" href="styles/general.css">
</head>
<body class="log-bg">
    <br>
    <div class="container-register">
        <div class="log-nav">
                <div class="log-left">
                    <div class="log-nav-logo">
                        <img src="images/animehaven_logo.png" alt="Anime Haven">
                    </div>
                </div>
            </div>
            <h1>Register</h1>
        <?php
        if (isset($_POST["submit"])) {
            $fullname = $_POST["full_name"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $passwordrepeat = $_POST["repeat_password"];
            $address = $_POST["address"];
            $country = $_POST["country"];
            $city = $_POST["city"];
            $province = $_POST["province"];
            $postalcode = $_POST["postal_code"];
            $errors = array();

            $passwordhash = password_hash($password, PASSWORD_DEFAULT);

            //Input checker
            if(empty($fullname) || empty($email) || empty($password) || empty($passwordrepeat) || empty($address) || empty($postalcode)) {
                array_push($errors, "All important fields are required");
            }
                //Email checker
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                array_push($errors, "Email is not valid");
            }
            //Password at least 8 long
            if(strlen($password)<8) {
                array_push($errors, "Password must be at least 8 characters long");
            }
            //Password checker
            if($password !== $passwordrepeat) {
                array_push($errors, "Password does not match");
            }
            //Email repeat checker
            require_once "connection.php";
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            $rowCount = mysqli_num_rows($result);
            if ($rowCount>0) {
                array_push($errors, "Email already exists");
            }
            //Postal code checker
            if(!is_numeric($postalcode)) {
                array_push($errors, "Postal Code must only contain numbers");
            }
            elseif(strlen($postalcode)>4) {
                array_push($errors, "Postal Code must not exceed 4 digits");
            }
            //Display error messages
            if(count($errors)>0) {
                foreach($errors as $error) {
                    echo "<div class='log-alert log-alert-danger'>$error</div>";
                }
            }
            else{
                //Insert into database
                $sql = "INSERT INTO users (full_name, email, password, address, country, city, province, postal_code) VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )";
                $stmt = mysqli_stmt_init($conn);
                $prepareStmt = mysqli_stmt_prepare($stmt, $sql);
                if($prepareStmt) {
                    mysqli_stmt_bind_param($stmt, "ssssssss", $fullname, $email, $passwordhash, $address, $country, $city, $province, $postalcode);
                    mysqli_stmt_execute($stmt);
                    //echo "<div class='log-alert log-alert-success'>You are registered successfully.</div>";
                    header("Location: login.php");
                }
                else{
                    die("Something went wrong.");
                }
            }

        }
        ?>
        <form action="registration.php" method="post">
        <div class="form-group">
            <a href="homepage.php">Back to homepage</a>
        </div>
        <div class="form-group"> <!--username & email-->
            <input type="text" class="form-control" name="full_name" placeholder="Full Name*" value="<?php echo isset($_POST['full_name']) ? $_POST['full_name'] : ''; ?>">
            <input type="email" class="form-control form-right" name="email" placeholder="Email*" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>">
        </div>
        <div class="form-group"> <!--password & password repeat-->
            <input type="password" class="form-control" name="password" placeholder="Password*">
            <input type="password" class="form-control form-right" name="repeat_password" placeholder="Repeat Password*">
        </div>
        <div class="form-group"> <!--address-->
            <input type="text" class="form-control form-address" name="address" placeholder="Address*" value="<?php echo isset($_POST['address']) ? $_POST['address'] : ''; ?>">
        </div>
        <div class="form-group"> <!--country & city-->
            <label for="country">Country: </label>
            <select name="country" class="form-control form-select">
                <option value="Philippines" selected>Philippines</option>
            </select>
            <input type="text" class="form-control form-right" name="city" placeholder="City" value="<?php echo isset($_POST['city']) ? $_POST['city'] : ''; ?>">
        </div>
        <div class="form-group"> <!--province & postal code-->
            <input type="text" class="form-control" name="province" placeholder="Province" value="<?php echo isset($_POST['province']) ? $_POST['province'] : ''; ?>">
            <input type="text" class="form-control form-right" name="postal_code" placeholder="Postal Code*" value="<?php echo isset($_POST['postal_code']) ? $_POST['postal_code'] : ''; ?>">
        </div>
        <input type="submit" class="log-btn" name="submit" value="Register">
        <p class="log-writing">Already registered? <a href="login.php">Go to login</a></p>
        </form>
    </div>
</body>
</html>
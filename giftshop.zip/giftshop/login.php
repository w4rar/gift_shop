<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!--
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    Tanggalin mo nalang yung bootstrap kung di kailangan-->
    <link rel="stylesheet" href="styles/general.css">
</head>
<body class="log-bg log-body">
    <div class="container-login">
        <div class="log-nav">
                <div class="log-left">
                    <div class="log-nav-logo">
                        <img src="images/animehaven_logo.png" alt="Anime Haven">
                    </div>
                </div>
            </div>
            <h1>Login</h1>
        <?php
        if(isset($_POST["login"])) {
            $email = $_POST["email"];
            $password = $_POST["password"];
            require_once "connection.php";
            $sql = "SELECT email, password FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            //$sql = "SELECT * FROM users WHERE email = '$email'";
            //$result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if($user) {
                //$user = $result->fetch_assoc();
                //Check password from database
                if (password_verify($password, $user["password"])) {
                    session_start();
                    $_SESSION['email'] = $user['email'];
                    $_SESSION["user"] = "yes";
                    header("Location: homepage.php");
                    die();
                }
                else{
                    //error message mali password
                    echo "<div class='log-alert log-alert-danger'>Password does not match</div>";
                }
            }
            else{
                //error message wala email sa database
                echo "<div class='log-alert log-alert-danger'>Email does not match</div>";
            }
        }
        ?>
        <form action="login.php" method="post">
            <div class="form-group">
                <a href="homepage.php">Back to homepage</a>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Enter Email" class="form-control">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Enter Password" class="form-control">
            </div>
            <div class="form-group">
                <input type="submit" name="login" value="Login" class="log-btn">
            </div>
            <div>
                <p>Not registered yet? <a href="registration.php">Register here</a></p>
            </div>
        </form>
    </div>
</body>
</html>